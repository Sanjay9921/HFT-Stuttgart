package observer.pattern.aspects;

/**
 * A Default-Aspect which may be used
 * for the observer-pattern.
 *
 */
public enum Aspect {
	
	NOTIFICATION

}
