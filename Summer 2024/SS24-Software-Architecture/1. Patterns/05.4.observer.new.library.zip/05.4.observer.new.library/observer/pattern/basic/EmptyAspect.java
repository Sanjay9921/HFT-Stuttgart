package observer.pattern.basic;

public enum EmptyAspect {
	
}
