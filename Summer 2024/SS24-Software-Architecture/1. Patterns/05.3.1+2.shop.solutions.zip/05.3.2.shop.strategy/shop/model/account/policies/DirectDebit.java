package shop.model.account.policies;

import shop.model.account.PaymentPolicy;

public class DirectDebit implements PaymentPolicy {
	
	private String bankno, accountno;

	public DirectDebit(String bankno, String accountno) {
		this.bankno = bankno.replaceAll("\\D+","");
		this.accountno = accountno.replaceAll("\\D+","");
	}

	@Override
	public void pay(String orderId, double amount) {
		System.out.println(orderId + ": " + amount + "� will be transfered from your account.\n");
	}

	@Override
	public String toString() {
		return "DirectDebit " + bankno + "|" + accountno;
	}
}
