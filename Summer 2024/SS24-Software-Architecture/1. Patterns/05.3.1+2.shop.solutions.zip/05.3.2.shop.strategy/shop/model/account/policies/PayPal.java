package shop.model.account.policies;

import shop.model.account.PaymentPolicy;

public class PayPal implements PaymentPolicy {
	
	private String eMail;

	public PayPal(String eMail) {
		this.eMail = eMail.replaceAll("\\s", "");
	}

	@Override
	public void pay(String orderId, double amount) {
		System.out.println(orderId + ": Please transfer " + amount + " with PayPal.\n");
	}

	@Override
	public String toString() {
		return "PayPal from " + eMail;
	}
}
