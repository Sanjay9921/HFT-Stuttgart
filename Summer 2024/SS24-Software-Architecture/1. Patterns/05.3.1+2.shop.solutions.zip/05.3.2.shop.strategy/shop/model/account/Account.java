package shop.model.account;

import java.util.Date;

import shop.model.mobile.MobilePhone;
import shop.model.order.Order;
import shop.model.products.Product;

public class Account{
	
	private String first, last, phone, user, pass;
	private PaymentPolicy policy;
	
	private boolean loggedIn = false;
	private Order order;
	
	private MobilePhone mobilePhone = null;

	public Account(String first, String last) {
		this(first, last, "", (first + "." + last).toLowerCase(), "secret");
	}

	public Account(String first, String last, String phone, String user, String pass) {
		this.first = first.trim();
		this.last = last.trim();
		this.phone = phone.trim();
		this.user = user.trim().toLowerCase();
		this.pass = pass.trim();
		this.order = new Order();

		if(phone.length() != 0){
			mobilePhone = new MobilePhone(phone);
			mobilePhone.dispose();
		}
	}

	public boolean owns(String user){
		return this.user.equals(user);
	}

	public boolean login(String user, String pass){
		loggedIn = this.user.equals(user) && this.pass.equals(pass);
		return loggedIn;
	}
	
	public void logout(){
		loggedIn = false;
	}
	
	public String getPhone(){
		return phone;
	}

	public void add(Product product){
		if((order.isEmpty() || order.isDigital()) && product.isPhysical())
			order.setShipment();
		order.add(product);
	}

	public void clearOrder() {
		order = new Order();
	}
	
	public boolean isDigitalOrder(){
		return order.isDigital();
	}

	public boolean isPhysicalOrder(){
		return order.isPhysical();
	}
	
	public int getCosts(){
		return order.getCosts();
	}

	public double getCostsAsEuro(){
		return order.getCosts() / 100.0;
	}
	
	public void setPolicy(PaymentPolicy policy) {
		this.policy = policy;
	}
	
	public String getPolicyAsString(){
		if(policy == null)
			return "";
		else
			return policy.toString();
	}

	public void addExpress(){
		if(order.isPhysical())
			order.setExpress();
	}
	
	public void addTracking(){
		order.setTracking();
	}
	
	public void complete(){
		if(!loggedIn)
			return;
		
		if(order.isEmpty() || policy == null)
			return;
		
		policy.pay("Order of " + new Date(), this.getCostsAsEuro());
		
		order.deliver();
		
		this.clearOrder();		
	}

	public void showMobile(){
		if(mobilePhone != null && !mobilePhone.isVisible()){
			mobilePhone.pack();
			mobilePhone.setVisible(true);
		}
	}

	@Override
	public String toString() {
		return first + " " + last + "; open orders:\n" + order;
	}
}
