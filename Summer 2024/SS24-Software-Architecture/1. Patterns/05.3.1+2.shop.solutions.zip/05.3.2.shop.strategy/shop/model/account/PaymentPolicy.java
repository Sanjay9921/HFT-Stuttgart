package shop.model.account;

public interface PaymentPolicy {
	
	public void pay(String orderId, double amount);

}
