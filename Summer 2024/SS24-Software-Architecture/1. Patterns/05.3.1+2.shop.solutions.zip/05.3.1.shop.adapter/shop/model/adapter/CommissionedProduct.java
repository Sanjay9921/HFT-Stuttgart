package shop.model.adapter;

import an.additional.set.of.products.Article;
import shop.model.products.Product;

public class CommissionedProduct implements Product{
	
	private Article article;

	public CommissionedProduct(Article article) {
		super();
		this.article = article;
	}

	@Override
	public String getName() {
		return article.getDescription();
	}

	@Override
	public int getPrice() {
		return (int) (article.getPriceWithoutTaxes() * 119);
	}

	@Override
	public int getDeliveryPeriod() {
		// by default these products take 10 days to deliver.
		return 10;
	}

	@Override
	public boolean isDigital() {
		// by default these products are only physical.
		return false;
	}

	@Override
	public boolean isPhysical() {
		// by default these products are only physical.
		return true;
	}

	@Override
	public String toString() {
		String name = this.getName();
		return (name.length() < 20 ? name : name.substring(0, 20) + "...") + " (" + getPrice()/100.0 + "�, comm.)";
	}
}
