package shop.model.products;

public interface Product {

	public String getName();

	public int getPrice();

	public int getDeliveryPeriod();

	public boolean isDigital();

	public boolean isPhysical();
}