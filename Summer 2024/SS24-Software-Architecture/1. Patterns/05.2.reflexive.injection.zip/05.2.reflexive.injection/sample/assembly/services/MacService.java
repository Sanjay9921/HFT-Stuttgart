package sample.assembly.services;
import sample.app.Service;

public class MacService implements Service {

	@Override
	public void call() {
		System.out.println("Mac");
	}

}
