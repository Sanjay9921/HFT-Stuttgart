package sample.assembly.services;
import sample.app.Service;

public class WindowsService implements Service {

	@Override
	public void call() {
		System.out.println("Windows");
	}

}
