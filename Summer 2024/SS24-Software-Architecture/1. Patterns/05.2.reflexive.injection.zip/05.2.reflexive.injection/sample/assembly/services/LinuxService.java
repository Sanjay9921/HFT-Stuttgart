package sample.assembly.services;
import sample.app.Service;

public class LinuxService implements Service {

	@Override
	public void call() {
		System.out.println("Linux");
	}

}
