package sample.assembly;

import java.lang.reflect.Field;

import sample.app.Service;
import sample.assembly.services.LinuxService;
import sample.assembly.services.MacService;
import sample.assembly.services.WindowsService;

public class Assembler {
	
	public static void autowire(Object obj) {
		Class<?> cls = obj.getClass();
		for(Field field : cls.getDeclaredFields())
			if(field.getType() == Service.class && field.isAnnotationPresent(Autowired.class))
				inject(field, obj);		
	}

	private static Service getService() {
		String osName = System.getProperty("os.name").toLowerCase();
	    Service service;
		if(osName.indexOf("win") >= 0)		service = new WindowsService();
		else if(osName.indexOf("mac") >= 0)	service = new MacService();
		else if((osName.indexOf("ix") > 0))	service = new LinuxService();
		else
			throw new IllegalArgumentException("Cannot instanitate " + osName);
		return service;
	}

	private static void inject(Field field, Object obj) {
		Service service = getService();
		try {
			field.setAccessible(true);
			field.set(obj, service);
		} catch (IllegalArgumentException | IllegalAccessException e) {
			e.printStackTrace();
		}		
	}
}
