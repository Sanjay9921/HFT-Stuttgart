package sample.app;

import sample.assembly.Autowired;

public class Client {
	
	@Autowired
	private Service service;

	public void doSomething() {
		service.call();
	}

}
