package sample.app;

public interface Service {

	void call();

}
