package sample.main;

import sample.app.Client;
import sample.assembly.Assembler;

public class Main {

	public static void main(String[] args) throws ClassNotFoundException {
		Client client = new Client();
		Assembler.autowire(client);
		client.doSomething();
	}

}
