package main;

import model.ObservedModel;
import observer.pattern.basic.Observer;
import view.ObservingComponent;

public class Main {

	 public static void main(String[] args) { 
		 ObservedModel observable = new ObservedModel(); 
		 Observer<String> observer = new ObservingComponent("Observer 1"); 
		 Observer<String> observer2 = new ObservingComponent("Observer 2"); 
		 
		 observable.addObserver(observer); 
		 observable.addObserver(observer2); 
		 observable.setData("new value"); 
	} 
}
