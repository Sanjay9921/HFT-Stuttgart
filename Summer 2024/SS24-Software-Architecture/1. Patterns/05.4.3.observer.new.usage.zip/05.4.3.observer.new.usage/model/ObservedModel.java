package model;

import observer.pattern.basic.Observable;

public class ObservedModel implements Observable<String> {
	 
	 private String data; 
	 
	 public void setData(String data) {
		 this.data = data;
		 this.notifyObservers(data);
	 }

	@Override
	public String toString() {
		return "ObservedModel [data=" + data + "]";
	}
}
