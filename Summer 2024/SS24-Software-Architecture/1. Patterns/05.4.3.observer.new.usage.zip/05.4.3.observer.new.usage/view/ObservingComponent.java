package view;

import observer.pattern.basic.Observer;

public class ObservingComponent implements Observer<String> {

	private String id;

	 public ObservingComponent(String id) {
		super();
		this.id = id;
	}

	@Override
	public void update(String data) {
		 System.out.println(id + " received: " + data); 
	} 
}
